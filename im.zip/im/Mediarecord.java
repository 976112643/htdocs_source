package im;

import java.io.File;
import java.io.IOException;

import android.media.MediaRecorder;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.Toast;

import com.cnsunrun.support.utils.AHandler;
import com.cnsunrun.support.utils.AHandler.Task;

public class Mediarecord {
	MediaRecorder mediaRecorder;// 录音
	File audioFile;// 路径
	private long startTime; // 开始时间
	private long endTime; // 结束时间
	private long voice_time = 0; // 结束时间

	public long getVoice_time() {
		return voice_time;
	}

	int time = 60;
	Task task;

	// 初始化 录音器
	public void initlization() throws IOException {
		startTime = System.currentTimeMillis();
		mediaRecorder = new MediaRecorder();
		// 设置音频来源（MIC表示麦克风）
		mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
		// 设置音频输出格式（默认的输出格式）
		mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
		// 设置音频编码方式（默认的编码方式）
		mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
		// 创建一个临时的音频输出文件
		audioFile = File.createTempFile("record_", ".amr");
		// 指定音频输出文件
		mediaRecorder.setOutputFile(audioFile.getAbsolutePath());
		// 设置最大的时间
		mediaRecorder.prepare();
		mediaRecorder.start();

	}

	public File getFilePath() {
		return audioFile;
	}

	// 停止录音
	public long stopRecord() {
		if (mediaRecorder == null)
			return 0L;
		endTime = System.currentTimeMillis();
		mediaRecorder.stop();
		mediaRecorder.reset();
		mediaRecorder.release();
		mediaRecorder = null;
		voice_time = endTime - startTime;
		return endTime - startTime;
	}

	public void attachRecorder(final Button v, final onRecordCallback callback) {
		v.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {
				// TODO Auto-generated method stub
				int x = (int) arg1.getX();// 获得x轴坐标
				int y = (int) arg1.getY();// 获得y轴坐标
				switch (arg1.getAction()) {
				case MotionEvent.ACTION_DOWN:
					try {
						time(v);
						Mediarecord.this.initlization();
						if (!callback.recordStart())
							Toast.makeText(v.getContext(), "开始录音", 300).show();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					break;
				case MotionEvent.ACTION_UP:
					// 如果想要取消，根据x,y的坐标看是否需要取消
					Mediarecord.this.stopRecord();
					// 线程关闭
					Mediarecord.this.task.cancel();
					if (Mediarecord.this.wantToCancle(x, y, v)) {
						Mediarecord.this.audioFile.delete();
						Mediarecord.this.cancle();
						if (!callback.recordCancel())
							Toast.makeText(v.getContext(), "取消录音", 300).show();
					} else {
						if (!callback.recordFinish(getVoice_time(), audioFile)) {
							Toast.makeText(v.getContext(), "完成录音", 300).show();
						}

					}

					break;

				default:
					break;
				}
				return false;
			}
		});
	}

	// 计时器
	 void time(final Button v) {

		if (task == null) {
			AHandler.runTask(task = new Task() {
				public void update() {
					if (time > 0) {
						time--;
						v.setText("剩余" + time + "秒");

					} else if (time == 0) {
						task.cancel();
					}
				}

				public boolean cancel() {
					boolean flag = super.cancel();
					time = 60;
					task = null;
					v.setText("录音");
					return flag;
				}

			}, 0, 1000);
		}
	}

	// 按键范围
	public boolean wantToCancle(int x, int y, Button v) {
		if (x < -20 || x > v.getWidth() + 20) { // 超过按钮的宽度
			return true;
		}
		// 超过按钮的高度
		if (y < -20 || y > v.getHeight() + 20) { return true; }

		return false;
	}

	// 语音清空
	public void cancle() {
		audioFile = null;
	}

	public static abstract class onRecordCallback {
		public boolean recordStart() {
			return false;
		}

		public boolean recordFinish(long time, File audiofile) {
			return false;
		}

		public boolean recordCancel() {
			return false;
		}
	}
}
