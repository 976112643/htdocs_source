package im;

import im.conn.IMBaseClient;
import im.conn.IMClientListener;
import im.conn.ReceiveListener;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

/**
 *
 * @author WQ 2015年10月15日
 */
public class TestCilent {
	public static byte[] intToBytes2(int value) {
		byte[] src = new byte[4];
		src[0] = (byte) ((value >> 24) & 0xFF);
		src[1] = (byte) ((value >> 16) & 0xFF);
		src[2] = (byte) ((value >> 8) & 0xFF);  
		src[3] = (byte) (value & 0xFF);
		return src;
	}
	public static int bytesToInt(byte[] src, int offset) {
		int value;
		value = (int) ((src[offset+3] & 0xFF) | ((src[offset + 2] & 0xFF) << 8) | ((src[offset + 1] & 0xFF) << 16) | ((src[offset ] & 0xFF) << 24));
		return value;
	}
	static class mess {
		public int code;
		public int cmd;
		public byte[] data;

		public mess(int code, int cmd, byte[] data) {
			super();
			this.code = code;
			this.cmd = cmd;
			this.data = data;
		}

		public byte[] toByte() {
			byte bytes[] = new byte[data.length + 8];
			System.arraycopy(intToBytes2(code), 0, bytes, 0, 4);
			System.out.println(Arrays.toString(bytes));
			System.arraycopy(intToBytes2(cmd), 0, bytes, 4, 4);
			System.out.println(Arrays.toString(bytes));
			System.arraycopy(data, 0, bytes, 8, data.length);
			System.out.println(Arrays.toString(bytes));
			return bytes;
		}
	}
	public static void main(String[] args) throws UnsupportedEncodingException, UnknownHostException {

		byte bytes[]=intToBytes2(101);
		System.out.println(Arrays.toString(bytes));
		System.out.println(bytesToInt(bytes, 0));
		
		   
		// BaseClient client=new BaseClient("127.0.0.1",1428) {};
		String IP="192.168.2.112";
		int port=8080;//5543
//		IP=InetAddress.getLocalHost().getHostAddress();
		IMBaseClient client = new IMBaseClient(IP, port) {};
		client.start();
		client.setIMClientListener(new IMClientListener() {

			@Override
			public void receive(byte[] data) {
				System.out.println("接收到:[" + new String(data) + "]");
			}
		});
		client.sendMsg("// 来自客户端的请求\n".getBytes("utf-8"));
		// client.sendMsgAsyn("哈哈".getBytes(),new sendListener() {
		//
		// @Override
		// public void sendfinish(int status, String msg) {
		// System.out.println(msg);
		// }
		// });
		// @B#@V0118682190000805959460040288604008@E#@
		// Message mess =
		// Message.create().setVersion("V01").setDeviceToken("8682190000805959460040288604008").setContent(
		// "5959460040288604008");
		// MessageCilent clinet = new MessageCilent();
		// clinet.start();
		// clinet.addReceiveListener(new MessageReceiveListener() {
		//
		// @Override
		// public void receive(Message message) {
		// // System.out.println("解析的消息"+message);
		// }
		// @Override
		// public void receive(byte[] data) {
		// System.out.println("服务端发来的消息:" + new String(data));
		// super.receive(data);
		// }
		// });
		//
		// clinet.sendMsgAsyn(mess.getByte(), new sendListener() {
		// @Override
		// public void sendfinish(int status, String msg) {
		// System.out.println(status + "  发送成功");
		// }
		// });
		// String content = "测试消息可以有多长呢";
		// for (int i = 0; i < 1000; i++) {
		// clinet.sendMsg(mess.getByte());
		// System.out.println(content.length());
		// }
	}
}
