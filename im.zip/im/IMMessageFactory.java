package im;

import im.bean.IMMessage;
import im.bean.IMMessage.Direct;
import im.bean.IMMessage.IMContact;
import im.bean.IMMessage.Type;

/**
 * 消息工厂
 * @author WQ 下午4:51:28
 */
public class IMMessageFactory {
	
	
	/**
	 * 创建文本消息
	 * 
	 * @param content
	 * @param from
	 * @param to
	 * @return
	 */
	public static IMMessage createText(String content, IMContact from, IMContact to) {
		IMMessage message = new IMMessage();
		message.setBody(content);
		message.setFrom(from);
		message.setTo(to);
		message.setDirect(Direct.SEND);
		return message;
	}
	public static IMMessage createImage(String path, IMContact from, IMContact to) {
		IMMessage message = new IMMessage(Type.IMAGE);
//		message.setBody(content);
		message.setFrom(from);
		message.setTo(to);
		message.setDirect(Direct.SEND);
		message.addAttribute("url", path); 
		return message;
	}
	public static IMMessage createVoice(String path, IMContact from, IMContact to) {
		IMMessage message = new IMMessage(Type.VOICE);
//		message.setBody(content);
		message.setFrom(from);
		message.setTo(to);
		message.setDirect(Direct.SEND);
		message.addAttribute("url", path); 
		return message;
	}
	/**
	 * 创建指令消息
	 * @param key
	 * @param cmd
	 * @param from
	 * @param to
	 * @return
	 */
	public static IMMessage createCmd(String cmd, IMContact from, IMContact to) {
		IMMessage message = new IMMessage(Type.CMD);
		message.setFrom(from);
		message.setTo(to);
		message.addAttribute("cmd", cmd);
		message.setDirect(Direct.SEND);
		return message;
	}
}
