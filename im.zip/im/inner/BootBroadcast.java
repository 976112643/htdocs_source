package im.inner;

import im.conn.IMService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * @author WQ 下午5:13:47
 */
public class BootBroadcast extends BroadcastReceiver implements Global {
	@Override
	public void onReceive(Context context, Intent intent) {
		if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
			Intent localIntent = new Intent(context, IMService.class);
			localIntent.putExtra("reason", "boot");
			context.startService(localIntent);
		}
	}
}
