package im.inner;

public interface Global {
	public static int CMD_START = 0x0055;
	public static int CMD_STOP = 0x0056;

	// 速度阈值，当摇晃速度达到这值后产生作用
	public static int SPEED_SHRESHOLD = 2000;
	// 两次检测的时间间隔
	public static long MIN_INTERVAL_TIME = 100;
	public static long MAX_INTERVAL_TIME = 1000 * 30;//30s最大间隔,超过后重新统计步数
	public static long SCAN_INTERVAL = 1000*60;
	public static int RECORD_INTERVAL_NUM = 8;
	
	public static String ACTION_START_SERVICE="com.service.LocationUploadService";
}
