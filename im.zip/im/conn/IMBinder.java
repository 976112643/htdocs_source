package im.conn;

import android.os.Binder;

public class IMBinder extends Binder  {
	IMService service;
	public IMBinder(IMService service) {
		this.service=service;
		// TODO Auto-generated constructor stub
	}
	public IMService getIMService() {
		return service;
	}

	public void addIMClientListener(IMClientListener listener) {
		getIMService().addIMClientListener(listener);
	}

	public void sendMsgAsyn(IMMessageListener message, IMSendListener listener) {
		
	}

}