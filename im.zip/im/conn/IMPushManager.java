package im.conn;

import im.bean.IMMessage;
import android.content.Context;
import android.content.Intent;

public class IMPushManager {
	static IMPushManager _SELF = new IMPushManager();

	IMPushManager() {}

	public void addIMClientListener(Context context, IMClientListener listener) {
		context.startService(new Intent(context, IMService.class));
		context.bindService(new Intent(context, IMService.class), listener, Context.BIND_AUTO_CREATE);
	}

	public void removeIMClientListener(Context context,IMClientListener listener){
		context.unbindService(listener);
	}
	
	public static IMPushManager getInstance() {
		return _SELF;
	}

	public void sendMessage(IMMessage message, IMSendListener listener) {
		IMService.sendMessage(message, listener);
	}
}
