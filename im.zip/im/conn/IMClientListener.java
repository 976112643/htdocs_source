package im.conn;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

/**
 * IM 客户端事件监听器
 * @author WQ 上午11:30:34
 */
public abstract class IMClientListener implements ReceiveListener, ConnectChangeListener, ServiceConnection {

	Throwable throwable;// 保存最近一次的错误信息;
	
	final public Throwable getThrowable() {
		return throwable;
	}

	final public void setThrowable(Throwable throwable) {
		this.throwable = throwable;
	}

	@Override
	public void receive(byte[] data) {
		// TODO Auto-generated method stub

	}

	@Override
	public void connected() {
		// TODO Auto-generated method stub

	}

	@Override
	public void disconnect(Throwable e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void connectTimeout() {
		// TODO Auto-generated method stub

	}

	@Override
	public void reconnected() {
		// TODO Auto-generated method stub

	}

	@Override
	final public void onServiceConnected(ComponentName name, IBinder service) {
//		服务绑定成功后进行 监听注册
		((IMBinder) service).addIMClientListener(this);
	}

	@Override
	final public void onServiceDisconnected(ComponentName name) {
		
	}
}
