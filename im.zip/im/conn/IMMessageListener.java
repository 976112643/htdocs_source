package im.conn;

import im.bean.IMMessage;
import im.util.MessageUtil;

/**
 * 消息监听类,对接收到的数据做简单的包装
 * @author WQ 下午3:59:44
 */
public abstract class IMMessageListener extends IMClientListener {
	@Override
	public void receive(byte[] data) {
		IMMessage message = MessageUtil.byte2Mess(data);
		if (MessageUtil.isVaild(message)) {
			receive(message);
		}
	}

	public abstract void receive(IMMessage message);
}
