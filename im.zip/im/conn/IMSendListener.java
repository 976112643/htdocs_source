package im.conn;
/**
 * 异步发送消息的结果回调
 * 
 * @author WQ 2015年10月14日
 */
public interface IMSendListener {
	public void sendSuccess();
	public void sendErr(Throwable throwable);
}