package im.conn;


/**
 * 连接接口
 * @author WQ 2015年10月14日
 */
public interface  ConnectBase {
	/**
	 * 同步模式发送数据
	 * 
	 * @param data
	 * @return
	 */
	public abstract boolean sendMsg(byte[] data);

	/**
	 * 异步模式发送数据
	 * 
	 * @param data
	 * @param listener
	 *            发送完毕的监听
	 */
	public abstract void sendMsgAsyn(byte[] data, IMSendListener listener);

	public abstract void setIMClientListener(IMClientListener listener);
}
