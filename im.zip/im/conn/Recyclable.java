package im.conn;

public interface Recyclable {
	public boolean isRecyle();
}
