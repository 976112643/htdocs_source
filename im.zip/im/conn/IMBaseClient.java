package im.conn;

import im.conf.IMConfig;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cnsunrun.support.utils.Logger;

import android.content.ServiceConnection;

/**
 * 客户端基础类
 * 
 * @author WQ 2015年10月14日
 */
public abstract class IMBaseClient implements ConnectBase, IMConfig {
	/** 客户端维持的与服务器的套接字对象 */
	private Socket socket;
	/** 服务器IP地址 */
	private String IP = SERVER_IP;
	/** 服务器端口 */
	private int PORT = SERVER_PORT;
	/** 线程池,用于维护消息接收线程和异步消息发送线程 */
	private ExecutorService executors;
	/** 客户端运行状态标识 */
	private boolean isRun = false;

	/** 上一次成功操作的时间,用于判定连接存活状态 */
	private long firstTime = 0;// 上一次操作时间
	/** 超时次数 */
	private int faild_count = 0;
	/** 默认监听器 */
	IMClientListener clientListener = new IMClientListener() {};

	public IMBaseClient(String ip, int port) {
		this.IP = ip;
		this.PORT = port;
	}

	public void setIMClientListener(IMClientListener clientListener) {
		if (clientListener != null) {
			this.clientListener = clientListener;
		}
	}

	/**
	 * 启动客户端 初始化连接,和相关线程
	 */
	public synchronized void start() {
		if (isRun)
			return;
		initThreadPool();
		executors.execute(new Runnable() {

			@Override
			public void run() {
				try {
					initSocket();
				} catch (IOException e) {
					clientListener.setThrowable(e);
					Logger.D("初始化异常:" + e.getLocalizedMessage());
					e.printStackTrace();
				}
				updateFirstTime();
				isRun = true;
				executors.execute(getReceiver());// 执行消息接收线程
			}
		});

	}

	/**
	 * 停止客户端 关闭连接及相关线程 释放资源
	 */
	public synchronized void stop() {
		if (!isRun)
			return;
		executors.shutdown();
		close(socket);
		socket = null;
		executors = null;
		isRun = false;
	}

	/**
	 * 重连
	 * 
	 * @return
	 */
	public synchronized void reconnection() {
		if (hasConnect())
			return;
		initThreadPool();
		executors.execute(new Runnable() {

			@Override
			public void run() {
				try {
					initSocket();
					if (clientListener != null) {
						clientListener.reconnected();
					}
				} catch (IOException e) {
					e.printStackTrace();
					clientListener.setThrowable(e);
				}
			}
		});

	}

	void initThreadPool() {
		if (executors == null || executors.isShutdown()) {
			executors = Executors.newScheduledThreadPool(3);
		}
	}

	/**
	 * 初始化/重新建立连接
	 * 
	 * @throws IOException
	 */
	private void initSocket() throws IOException {

		if (faild_count > MAX_LOST_NUM || !hasConnect()) {
			socket = createSocket(IP, PORT);
			socket.setKeepAlive(true);
			socket.setSoTimeout(TIMEOUT);
			clientListener.connected();
			Logger.D(socket.getInetAddress().toString() +":"+PORT+ "  连接成功");
		}

	}

	public IMBaseClient() {}

	/**
	 * 数据发送方法 同步进行发送
	 * 
	 * @param data
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private OutputStream send(byte[] data) throws IOException {
		initSocket();
		OutputStream send = socket.getOutputStream();
		send.write(data);
		send.flush();
		sleep(200);
		return send;
	}

	/**
	 * 数据接收方法
	 * 
	 * @return
	 * @throws IOException
	 */
	private byte[] receive() throws IOException {
		initSocket();
		InputStream receive = socket.getInputStream();
		byte[] buff = new byte[MAX_SIZE];
		int len = receive.read(buff);
		return Arrays.copyOf(buff, len);
	}

	@Override
	public boolean sendMsg(byte[] data) {
		try {
			Logger.E(String.format("发送%s", new String(data)));
			send(data);
			return updateFirstTime();
		} catch (IOException e) {
			e.printStackTrace();
			Logger.D("消息发送失败:" + e.getLocalizedMessage());
		} finally {}

		return false;
	}

	@Override
	public void sendMsgAsyn(final byte[] data, final IMSendListener listener) {
		executors.execute(new Runnable() {
			@Override
			public void run() {
				try {
					Logger.E(String.format("发送%s", new String(data)));
					send(data);
					if (listener != null) {
						listener.sendSuccess();
					}
					updateFirstTime();
					return;
				} catch (IOException e) {
					if (listener != null) {
						listener.sendErr(e);
					}
					e.printStackTrace();
					Logger.D("消息发送失败:" + e.getLocalizedMessage());
				}
			}
		});
	}

	/**
	 * 检测是否需要发送心跳包
	 * 
	 * @return
	 */
	public boolean checkheattime() {
		if (System.currentTimeMillis() - firstTime >= HEART_RATE) {
			updateFirstTime();
			return true;
		}
		return false;
	}

	/**
	 * 更新操作时间为当前时间,并重置失败次数
	 */
	private boolean updateFirstTime() {
		Logger.D("更新最近操作时间");
		this.firstTime = System.currentTimeMillis();
		faild_count = 0;
		return true;
	}

	/**
	 * 检查连接,并尝试重连
	 */
	protected void checkConnect() {
		try {
			int count=0;
			while (!hasConnect()) {
				synchronized (this) {
					if(count++<1){
					clientListener.disconnect(clientListener.getThrowable());// 连接断开
					}
					Logger.D("连接不可用.接收线程挂起");
					this.wait(RETRY_TIME);
				}
				Logger.D("尝试重新连接");
				initSocket();// 重试
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
			clientListener.setThrowable(e);
		} catch (IOException e) {
			 e.printStackTrace();
				clientListener.setThrowable(e);
		}
	}

	protected void checkHeat() {
		if (checkheattime()) {// 是否需要检测在线状态(长时间无操作时触发)
			boolean isSuccess = sendMsg(new byte[]
			{ -1, -1 });
			if (!isSuccess) {
				faild_count = faild_count + 1;
			}
		}
	}

	/**
	 * 尝试接收数据
	 */
	protected void tryReceive() {
		byte data[] = null;
		try {
			data = receive();// 扫描是否有数据可以接收
			if (data != null) {
				updateFirstTime();
				clientListener.receive(data);
			}
		} catch (SocketTimeoutException e) {
			clientListener.setThrowable(e);
			Logger.D("数据读取超时..");
			e.printStackTrace();
		} catch (ConnectException e) {
			clientListener.setThrowable(e);
			Logger.D("连接失败" + e);
			e.printStackTrace();
		} catch (SocketException e) {
			clientListener.setThrowable(e);
			close(socket);
			Logger.D("尝试接收数据时异常:" + e);
			e.printStackTrace();
		} catch (IOException e) {
			clientListener.setThrowable(e);
			e.printStackTrace();
		}
	}

	/**
	 * 获得一个消息接收线程
	 * 
	 * @return
	 */
	protected Runnable getReceiver() {
		return new Runnable() {
			@Override
			public void run() {
				while (isRun) {
					checkConnect();
					checkHeat();
					tryReceive();
				}
				Logger.D("消息接收线程停止运行");
			}
		};
	}

	/**
	 * 检查网络是否连接
	 * 
	 * @return
	 */
	public boolean hasConnect() {
		return !(socket == null || socket.isClosed() || socket.isInputShutdown() || socket.isOutputShutdown());
	}

	/**
	 * 创建一个套接字连接
	 * 
	 * @param host
	 * @param port
	 * @return
	 * @throws IOException
	 */
	public static synchronized Socket createSocket(String host, int port) throws IOException {
		Socket socket = new Socket(host, port);
		return socket;
	}

	/**
	 * 流和套接字等对象的关闭
	 * 
	 * @param closeables
	 */
	public static void close(Closeable... closeables) {
		if (closeables != null)
			for (Closeable closeable : closeables) {
				try {
					if (closeable != null)
						closeable.close();
				} catch (IOException e) {
					Logger.D("关闭失败:" + e);
				}
			}
	}

	public static void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
