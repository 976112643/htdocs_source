package im.conn;

import im.bean.IMMessage;
import im.conf.IMConfig;
import im.util.MessageUtil;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;

import com.cnsunrun.support.utils.Logger;
import com.cnsunrun.support.utils.UiUtils;

/**
 * 即时通信服务类 用于维持与服务器的连接,以及提供消息相关方法与监听
 * 
 * @author WQ 上午11:25:12
 */
public class IMService extends Service {
	/** IM客户端基类,提供连接以及通讯基本实现 */
	IMBaseClient client;
	/** binder对象,用于暴露服务示例 */
	IBinder serviceBinder = new IMBinder(this);
	Set<IMClientListener> listeners = new HashSet<IMClientListener>();
	static IMService _SELF;
	/** 用于与主线程通讯 */
	Handler mHander;

	@Override
	public IBinder onBind(Intent intent) {
		return serviceBinder;
	}

	/**
	 * 添加IM监听
	 * 
	 * @param listener
	 */
	public void addIMClientListener(IMClientListener listener) {
		listeners.add(listener);
	}

	@Override
	public void onCreate() {
		super.onCreate();
		init();
		_SELF = this;
	}

	private void init() {
		tryGc();
		mHander = new Handler();
		client = new IMBaseClient(IMConfig.SERVER_IP, IMConfig.SERVER_PORT) {};
		client.setIMClientListener(new IMClientListener() {
			@Override
			public void connected() {
				mHander.post(new Runnable() {
					@Override
					public void run() {
						UiUtils.shortM("已连接");
						for (IMClientListener imClientListener : listeners) {
							imClientListener.connected();

						}
					}
				});

			}

			@Override
			public void disconnect(final Throwable e) {
				mHander.post(new Runnable() {
					@Override
					public void run() {
						UiUtils.shortM("连接断开");
						for (IMClientListener imClientListener : listeners) {
							imClientListener.disconnect(e);
						}
					}
				});
			}

			@Override
			public void receive(final byte[] data) {
				mHander.post(new Runnable() {
					@Override
					public void run() {
						Logger.E("接收到信息:" + new String(data));
						for (IMClientListener imClientListener : listeners) {
							imClientListener.receive(data);
						}
					}
				});

			}

			@Override
			public void reconnected() {
				UiUtils.shortM("重新连接");
				mHander.post(new Runnable() {
					@Override
					public void run() {
						for (IMClientListener imClientListener : listeners) {
							imClientListener.reconnected();
						}
					}
				});

			}

			@Override
			public void connectTimeout() {
				UiUtils.shortM("连接超时");
				mHander.post(new Runnable() {
					@Override
					public void run() {
						for (IMClientListener imClientListener : listeners) {
							imClientListener.connectTimeout();
						}
					}
				});

			}
		});
		client.start();
	}

	private void tryGc() {
		if (client != null) {
			client.stop();
		}
	}

	/**
	 * 发送消息
	 * @param message
	 * @param lis
	 */
	public static void sendMessage(IMMessage message, final IMSendListener lis) {
		if (_SELF != null && _SELF.client != null) {
			_SELF.client.sendMsgAsyn(MessageUtil.mess2byte(message),
					new IMSendListener() {

						@Override
						public void sendSuccess() {
							_SELF.mHander.post(new Runnable() {

								@Override
								public void run() {
									lis.sendSuccess();
								}
							});
						}

						@Override
						public void sendErr(final Throwable throwable) {
							_SELF.mHander.post(new Runnable() {

								@Override
								public void run() {
									lis.sendErr(throwable);
								}
							});
						}
					});
		} else {
			lis.sendErr(new IOException("连接服务不可用."));
		}
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

}
