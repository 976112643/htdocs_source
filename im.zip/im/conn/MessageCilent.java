package im.conn;

import im.bean.Message;

/**
 * 消息处理客户端,扩展为指定格式消息
 * 
 * @author WQ 2015年10月15日
 */
public class MessageCilent extends IMBaseClient {
	public MessageCilent() {}

	public MessageCilent(String ip, int port) {
		super(ip, port);
	}


	public void sendMsgAsyn(Message message, IMSendListener listener) {
		super.sendMsgAsyn(message.getByte(), listener);
	}

	public boolean sendMsg(Message message) {
		return super.sendMsg(message.getByte());
	}

	@Override
	final public boolean sendMsg(byte[] data) {
		return super.sendMsg(data);
	}

	@Override
	final public void sendMsgAsyn(byte[] data, IMSendListener listener) {
		super.sendMsgAsyn(data, listener);
	}

	public static abstract class MessageReceiveListener implements ReceiveListener {
		@Override
		public void receive(byte[] data) {
			receive(Message.create().setByte(data));
		}

		public abstract void receive(Message message);
	}
}
