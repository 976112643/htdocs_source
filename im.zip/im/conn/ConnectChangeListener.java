package im.conn;

/**
 * 连接状态改变监听
 * @author WQ 上午9:23:51
 */
public interface  ConnectChangeListener {
	public void connected();//连接
	public void disconnect(Throwable e);//连接失败
	public void connectTimeout();//连接超时
	public void reconnected();//重连
}
