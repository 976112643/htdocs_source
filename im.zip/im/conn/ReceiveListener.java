package im.conn;

/**
 * 消息接收监听接口
 * 
 * @author WQ 2015年10月14日
 */
public interface ReceiveListener {
	public void receive(byte[] data);
}