package im.conf;

/**
 * 全局配置信息
 * @author WQ 2015年10月15日
 */
public interface IMConfig {
	/** 默认的服务Ip地址 */
	public  static String SERVER_IP = "192.168.1.200";
	/** 默认的服务端口 */
	public  static int SERVER_PORT = 8484;
	/** 心跳包间隔时长 */
	public static long HEART_RATE = 60 * 1000;
	public static long RETRY_TIME = 20*1000;//连接失败重试时间
	public static int MAX_LOST_NUM = 3;
	/** 设置数据请求/发送时超 */
	public static int TIMEOUT = 30 * 1000;
	/** 消息最大长度 */
	public static int MAX_SIZE = 1024 * 500;
	
	public  static String  SEND_MSG="im.action.send_message";
}
