package im.util;

import im.bean.IMMessage;

import com.cnsunrun.support.net.JsonDeal;

public class MessageUtil {
	public static byte[] mess2byte(IMMessage message) {
		return JsonDeal.object2Json(message).getBytes();
	}

	public static IMMessage byte2Mess(byte[] data) {
		return JsonDeal.json2Object(new String(data), IMMessage.class);
	}
	public static boolean isVaild(IMMessage mss){
		return mss!=null && mss.getType()!=null && mss.getType()!=IMMessage.Type.ping;
	}
}
