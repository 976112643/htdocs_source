package im.util;

import java.io.IOException;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;

import com.cnsunrun.support.utils.Logger;

public class VoiceManager {
	static VoiceManager _SELF;
	MediaPlayer player;

	public VoiceManager() {
		player = new MediaPlayer();
	}

	public MediaPlayer play(Context context, String url) {
		try {
			if (player.isPlaying()) {
				player.stop();
			}
			player.reset();
			Logger.E("播放地址" + url);
			// Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
			player.setDataSource(context, Uri.parse(url));
			player.prepare();
			player.start();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return player;
	}

	public static VoiceManager getInstance() {
		if (_SELF == null) {
			_SELF = new VoiceManager();
		}
		return _SELF;
	}
}
