package im.adapter;

import im.bean.IMMessage;
import im.bean.IMMessage.Direct;
import im.bean.IMMessage.Status;
import im.util.VoiceManager;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.cnsunrun.support.adapter.ViewHodler;
import com.cnsunrun.support.utils.Logger;
import com.cnsunrun.support.utils.UiUtils;
import com.cnsunrun.talk.R;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;

public class MessageAdapter extends BaseAdapter {
	/** 数据源对象 */
	protected List<IMMessage> mData;
	/** 上下文对象 */
	protected Context mContext;

	public MessageAdapter(Context context, List<IMMessage> data) {
		this.mContext = context;
		if (data == null)
			data = new ArrayList<IMMessage>();
		mData = data;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData.size();
	}

	@Override
	public int getViewTypeCount() {
		// TODO Auto-generated method stub
		return 8;
	}

	@Override
	public int getItemViewType(int position) {
		IMMessage message = getItem(position);

		switch (message.getType()) {
		case TEXT:
			return message.getDirect() == Direct.SEND ? MESSAGE_TYPE_SENT_TXT : MESSAGE_TYPE_RECV_TXT;
		case IMAGE:
			return message.getDirect() == Direct.SEND ? MESSAGE_TYPE_SENT_IMAGE : MESSAGE_TYPE_RECV_IMAGE;
		case VOICE:
			return message.getDirect() == Direct.SEND ? MESSAGE_TYPE_SENT_VOICE : MESSAGE_TYPE_RECV_VOICE;
		default:
			break;
		}

		return super.getItemViewType(position);
	}

	@Override
	public IMMessage getItem(int position) {
		// TODO Auto-generated method stub
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHodler holder = null;
		if (convertView == null) {
			convertView = createViewByMessage(getItem(position), position);
			holder = new ViewHodler(convertView);
		} else {
			holder = (ViewHodler) convertView.getTag();
		}
		switch (getItem(position).getType()) {
		case TEXT:
			handleText(getItem(position), holder, position);
			break;
		case IMAGE:
			handleImage(getItem(position), holder, position);
			break;
		case VOICE:
			handleVoice(getItem(position), holder, position);
			break;

		default:
			break;
		}

		return convertView;
	}

	/**
	 * 处理声音
	 * @param item
	 * @param holder
	 * @param position
	 */
	private void handleVoice(final IMMessage item, ViewHodler holder, int position) {
		holder.getView(R.id.iv_voice).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				VoiceManager.getInstance().play(mContext, item.getAttribute((item.getDirect() == Direct.SEND) ? "url" : "net_url"));
			}
		});
		holder.setText(R.id.tv_length, item.getAttribute("length"));
		holder.setVisibility(R.id.pb_sending, item.getStatus() == Status.INPROGRESS);
	}

	/**
	 * 处理图片信息,的显示与加载
	 * @param item
	 * @param holder
	 * @param position
	 */
	private void handleImage(IMMessage item, ViewHodler holder, int position) {
		Logger.E(item.getAttribute("url"));
		String url=item.getAttribute((item.getDirect() == Direct.SEND) ? "url" : "net_url");
	//	holder.setImageURL(R.id.iv_sendPicture, item.getAttribute((item.getDirect() == Direct.SEND) ? "url" : "net_url"));
		ImageView img=holder.getView(R.id.iv_sendPicture);
		ImageLoader.getInstance().displayImage(url, img, new SimpleImageLoadingListener(){
			@Override
			public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
				ImageView img=(ImageView) view;;
				loadedImage=UiUtils.getImageThumbnail(loadedImage,200,200);
				img.setImageBitmap(loadedImage);
				super.onLoadingComplete(imageUri, view, loadedImage);
			}
		});
		if (item.getDirect() == Direct.SEND)
			holder.setVisibility(R.id.pb_sending, item.getStatus() == Status.INPROGRESS);
	}

	/**
	 * 处理文本信息
	 * @param item
	 * @param holder
	 * @param position
	 */
	private void handleText(IMMessage item, ViewHodler holder, int position) {
		holder.setText(R.id.tv_chatcontent, item.getBody());
		if (item.getDirect() == Direct.SEND)
			holder.setVisibility(R.id.pb_sending, item.getStatus() == Status.INPROGRESS);
	}

	View inflate(int layId) {
		return LayoutInflater.from(mContext).inflate(layId, null);
	}

	private View createViewByMessage(IMMessage message, int position) {
		switch (message.getType()) {
		case IMAGE:
			return message.getDirect() == IMMessage.Direct.RECEIVE ? inflate(R.layout.row_received_picture) : inflate(R.layout.row_sent_picture);

		case VOICE:
			return message.getDirect() == IMMessage.Direct.RECEIVE ? inflate(R.layout.row_received_voice) : inflate(R.layout.row_sent_voice);
		case TEXT:
			return message.getDirect() == IMMessage.Direct.RECEIVE ? inflate(R.layout.row_received_message) : inflate(R.layout.row_sent_message);
		default:
			break;
		}
		return null;
	}

	private static final int MESSAGE_TYPE_RECV_TXT = 0;
	private static final int MESSAGE_TYPE_SENT_TXT = 1;
	private static final int MESSAGE_TYPE_SENT_IMAGE = 2;
	private static final int MESSAGE_TYPE_RECV_IMAGE = 5;
	private static final int MESSAGE_TYPE_SENT_VOICE = 6;
	private static final int MESSAGE_TYPE_RECV_VOICE = 7;
}
