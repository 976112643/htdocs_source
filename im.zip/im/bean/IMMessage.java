package im.bean;

import java.util.HashMap;
import java.util.Map;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 消息实体类
 * @author WQ 下午4:34:46
 */
public class IMMessage implements Parcelable, Cloneable {
	Type type = Type.TEXT;// 消息类型
	IMContact from;// 发送人
	IMContact to;// 接收人
	String body;// 消息内容
	String id;
	long msgTime;// 消息时间
	transient Status status=Status.CREATE;
	Map<String, String> attributes;// 消息附加属性
	transient Direct direct=Direct.RECEIVE;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Direct getDirect() {
		return direct;
	}

	public void setDirect(Direct direct) {
		this.direct = direct;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public IMMessage() {
		this.msgTime = System.currentTimeMillis();
	}

	public void addAttribute(String key, Object value) {
		if (this.attributes == null)
			this.attributes = new HashMap<>();
		this.attributes.put(key, String.valueOf(value));
	}

	public String getAttribute(String key) {
		if (this.attributes == null)
			return null;
		return this.attributes.get(key);
	}

	public IMMessage(Type type) {
		super();
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public IMContact getFrom() {
		return from;
	}

	public void setFrom(IMContact from) {
		this.from = from;
	}

	public IMContact getTo() {
		return to;
	}

	public void setTo(IMContact to) {
		this.to = to;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public long getMsgTime() {
		return msgTime;
	}

	public void setMsgTime(long msgTime) {
		this.msgTime = msgTime;
	}

	/**
	 * 联系人
	 * 
	 * @author WQ 下午4:41:28
	 */
	public static class IMContact implements Parcelable{
		public String id;
		public String username;
		public String nick;

		public IMContact() {
		}
		
		public IMContact(Parcel paramAnonymousParcel) {
			this.id=paramAnonymousParcel.readString();
			this.username=paramAnonymousParcel.readString();
			this.nick=paramAnonymousParcel.readString();
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
			this.id = this.username.hashCode() + "";
		}

		public String getNick() {
			return nick;
		}

		public void setNick(String nick) {
			this.nick = nick;
		}

		@Override
		public int describeContents() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public void writeToParcel(Parcel dest, int flags) {
			dest.writeString(id);
			dest.writeString(username);
			dest.writeString(nick);
		}
		
		public static final Parcelable.Creator<IMContact> CREATOR = new Parcelable.Creator<IMContact>() {
			public IMContact createFromParcel(Parcel paramAnonymousParcel) {
				return new IMContact(paramAnonymousParcel);
			}

			public IMContact[] newArray(int paramAnonymousInt) {
				return new IMContact[paramAnonymousInt];
			}
		};

	}

	/**
	 * 消息类型
	 * 
	 * @author WQ 上午11:29:14
	 */
	public static enum Type {
		TEXT, IMAGE, VIDEO, LOCATION, VOICE, FILE, CMD,ping;
	}
	public static enum Status{
		SUCCESS, FAIL, INPROGRESS, CREATE;
	}
	public enum Direct {
	    SEND, RECEIVE;
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.id);
		dest.writeString(this.type.name());
		dest.writeString(this.status.name());
		dest.writeParcelable(this.from, flags);
		dest.writeParcelable(this.to, flags);
		dest.writeString(this.body);
		dest.writeLong(this.msgTime);
		dest.writeMap(this.attributes); 
	}

	private IMMessage(Parcel paramParcel) {
		this.id=paramParcel.readString();
		this.type = Type.valueOf(paramParcel.readString());
		this.status=Status.valueOf(paramParcel.readString());
		this.from = ((IMContact) paramParcel.readParcelable(IMContact.class.getClassLoader()));
		this.to = ((IMContact) paramParcel.readParcelable(IMContact.class.getClassLoader()));
		this.body = paramParcel.readString();
		this.msgTime = paramParcel.readLong();
		this.attributes = paramParcel.readHashMap(HashMap.class.getClassLoader());
	}

	public static final Parcelable.Creator<IMMessage> CREATOR = new Parcelable.Creator<IMMessage>() {
		public IMMessage createFromParcel(Parcel paramAnonymousParcel) {
			return new IMMessage(paramAnonymousParcel);
		}

		public IMMessage[] newArray(int paramAnonymousInt) {
			return new IMMessage[paramAnonymousInt];
		}
	};
}
