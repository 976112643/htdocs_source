package im.bean;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;

public class Message implements Serializable {
	/** */
	private static final long serialVersionUID = -8762728008335332011L;
	private String version = "V01";
	private String str = "1";
	private String deviceToken = "10011001";
	private String content = "哈哈";
	public static String HEAD = "[@B#@";
	public static String END = "@E#@]";
	public static final String CHARSET = "UTF-8";

	public static Message create() {
		return new Message();
	}

	public String getVersion() {
		return version;
	}

	public Message setVersion(String version) {
		this.version = version;
		return this;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public Message setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
		return this;
	}

	public String getContent() {
		return content;
	}

	public Message setContent(String content) {
		this.content = content;
		return this;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static void main(String[] args) {
		System.out.println(new Message());
	}

	/**
	 * 把消息对象转为byte数组
	 * 
	 * @return
	 */
	public byte[] getByte() {
		try {
			return toString().getBytes(CHARSET);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return toString().getBytes();
		}
	}

	/**
	 * 从byte数组中解析Message内容
	 * 
	 * @param data
	 */
	public Message setByte(byte data[]) {
		// "@B#@V0118682190000805959460040288604008@E#@"
//		String split[] = new String(data).split(",");
//		if (split == null || split.length == 0) {
//			HEAD = new String(data, 0, 3);
//			version = new String(data, 9, 15);
//			System.out.println(HEAD + "  " + version);
//		}else {
//			
//		}
		return this;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(HEAD).append(',').append(version).append(',').append(str).append(',').append(
				deviceToken).append(',').append(content).append(',').append(END);
		return sb.toString();
	}
}
