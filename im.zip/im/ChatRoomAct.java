package im;

import im.Mediarecord.onRecordCallback;
import im.adapter.MessageAdapter;
import im.bean.IMMessage;
import im.bean.IMMessage.IMContact;
import im.bean.IMMessage.Status;
import im.bean.IMMessage.Type;
import im.conn.IMMessageListener;
import im.conn.IMPushManager;
import im.conn.IMSendListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.cnsunrun.base.Config;
import com.cnsunrun.support.net.NetUtils;
import com.cnsunrun.support.net.cache.NetSession;
import com.cnsunrun.support.uibase.PhotoSelActivity;
import com.cnsunrun.support.utils.Logger;
import com.cnsunrun.support.utils.UiUtils;
import com.cnsunrun.talk.R;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

public class ChatRoomAct extends Activity {
	List<IMMessage> messages = new ArrayList<IMMessage>();
	ListView list;
	Button send, switchMode, send_voice,send_img;
	EditText edittext;
	TextView connect_status;
	EditText username, tousername;
	boolean isText = true;
	MessageAdapter adapter;
	IMContact self = new IMContact(), to = new IMContact();
	NetSession session;
	final static String url = "http://192.168.2.111/manor/Home/SaveFile";
	final static String url2 = "http://api.shengzhihuan.com/App/AppCommon/Login";
	Mediarecord medre = new Mediarecord();
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_chatroom);
		session = NetSession.instance(this);
		send_voice = (Button) findViewById(R.id.send_voice);
		send_img=(Button) findViewById(R.id.send_img);
		list = (ListView) findViewById(R.id.list);
		send = (Button) findViewById(R.id.send);
		connect_status = (TextView) findViewById(R.id.connect_status);
		edittext = (EditText) findViewById(R.id.edittext);
		username = (EditText) findViewById(R.id.username);
		tousername = (EditText) findViewById(R.id.tousername);
		username.setText(Config.getLoginInfo().getNickname());
		tousername.setText(getIntent().getStringExtra("name"));
		self.setUsername(username.getText().toString());
		to.setUsername(tousername.getText().toString());
		list.setAdapter(adapter = new MessageAdapter(this, messages));
		
		send.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				self.setUsername(username.getText().toString());
				to.setUsername(tousername.getText().toString());
				session.put("username", username.getText().toString());
				session.put("tousername", tousername.getText().toString());
				final IMMessage message = IMMessageFactory.createText(edittext.getText().toString(), self, to);
				message.setStatus(Status.INPROGRESS);
				messages.add(message);
				reshList();
				IMPushManager.getInstance().sendMessage(message, new IMSendListener() {

					public void sendSuccess() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								message.setStatus(Status.SUCCESS);
							}
						});
						reshList();
					}

					public void sendErr(final Throwable throwable) {
						message.setStatus(Status.FAIL);
						reshList();
						UiUtils.shortM("消息发送失败!" + throwable);
					}
				});
			}
		});
		IMPushManager.getInstance().addIMClientListener(this, new IMMessageListener() {

			@Override
			public void receive(IMMessage message) {
				if (message.getType() != Type.CMD) {
					messages.add(message);
					// messages.add(message.getFrom().username + " 对你说:" +
					// message.getBody());
					reshList();
				}
			}

			@Override
			public void connected() {
				connect_status.setText(null);
			}

			@Override
			public void disconnect(Throwable e) {
				super.disconnect(e);
				connect_status.setText("连接服务不可用");
			}

			@Override
			public void reconnected() {
				super.reconnected();
				connect_status.setText("重连..");
			}
		});

		send_img.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(getApplication(), PhotoSelActivity.class),100);
			}
		});
		switchMode = (Button) findViewById(R.id.switchMode);
		switchMode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (isText) {
					isText = false;
					switchMode.setText("文本");
					send_voice.setVisibility(View.VISIBLE);
				} else {
					isText = true;
					switchMode.setText("语音");
					send_voice.setVisibility(View.GONE);
				}
			}
		});
		
		medre.attachRecorder(send_voice, new onRecordCallback() {
			@Override
			public boolean recordFinish(long time, File audiofile) {
				sendVoiceMessage(time, audiofile);
				return super.recordFinish(time, audiofile);
			}
		});

	}

	/**
	 * 语音消息发送
	 * 
	 * @param time
	 * @param audiofile
	 */
	private void sendVoiceMessage(long time, File audiofile) {
		final IMMessage message = IMMessageFactory.createVoice(medre.getFilePath().getAbsolutePath(), self, to);
		message.setStatus(Status.INPROGRESS);
		message.addAttribute("length", time/1000);
		messages.add(message);
		uploadFile(new File(message.getAttribute("url")), new TextHttpResponseHandler() {

			@Override
			public void onSuccess(int arg0, Header[] arg1, final String arg2) {
				message.addAttribute("net_url", arg2);
				IMPushManager.getInstance().sendMessage(message, new IMSendListener() {

					public void sendSuccess() {
						message.setStatus(Status.SUCCESS);
						reshList();
					}

					public void sendErr(final Throwable throwable) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								UiUtils.shortM("消息发送失败!" + throwable);
							}
						});
						message.setStatus(Status.FAIL);
						reshList();
					}
				});
			}

			@Override
			public void onFailure(int arg0, Header[] arg1, String arg2, Throwable arg3) {
				message.setStatus(Status.FAIL);
				reshList();
				Logger.E("  " + arg2 + " " + arg3);
			}
		});
		reshList();
	}
	

	private void sendImageMessage(String stringExtra) {
		final IMMessage message = IMMessageFactory.createImage(stringExtra, self, to);
		message.setStatus(Status.INPROGRESS);
		messages.add(message);
		uploadFile(new File(message.getAttribute("url")), new TextHttpResponseHandler() {

			@Override
			public void onSuccess(int arg0, Header[] arg1, final String arg2) {
				message.addAttribute("net_url", arg2);
				IMPushManager.getInstance().sendMessage(message, new IMSendListener() {

					public void sendSuccess() {
						message.setStatus(Status.SUCCESS);
						reshList();
					}

					public void sendErr(final Throwable throwable) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								UiUtils.shortM("消息发送失败!" + throwable);
							}
						});
						message.setStatus(Status.FAIL);
						reshList();
					}
				});
			}

			@Override
			public void onFailure(int arg0, Header[] arg1, String arg2, Throwable arg3) {
				message.setStatus(Status.FAIL);
				reshList();
				Logger.E("  " + arg2 + " " + arg3);
			}
		});
		reshList();
	}

	void uploadFile(File file, AsyncHttpResponseHandler responseHandler) {
		Logger.E("  " + file.exists());
		RequestParams params = new RequestParams();
		try {
			params.put("uploadfile", file);
			NetUtils.doPost(url, params, responseHandler);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void reshList() {
		adapter.notifyDataSetChanged();
		list.setSelection(messages.size() - 1);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode==100&& resultCode==RESULT_OK){
			sendImageMessage(data.getStringExtra(PhotoSelActivity.RESULT));
		}
		super.onActivityResult(requestCode, resultCode, data);
	}


}
