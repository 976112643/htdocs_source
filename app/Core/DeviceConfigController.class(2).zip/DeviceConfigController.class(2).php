<?php
namespace App\Controller\DeviceManage;
use   Common\Org\Common;
use   Common\Plugin\Center;

class DeviceConfigController extends BaseController {
	
	
	/*
	 * 获取设备配置报文
	 *		需求分析
	 *			获取设备配置报文
	 *		流程分析
	 *			1、
	 *			2、
	 *			3、
	 *			4、
	 *			5、
	 *
	 * @author	  陆龙飞 <747060156@qq.com>
	 * @date      2015-08-27
	 * 获取设备配置报文
	 * 测试地址   http://127.0.0.1/smh_crm/app/App/DeviceManage/DeviceConfig/api_get_config_one 	
	 *            http://59.175.146.174/smh_crm/app/App/DeviceManage/DeviceConfig/api_get_config?imei=358551050412329&key=fgmhaksjddfdkfg@#$$sdf%asd
	 * 提交方式   GET
		 request 参数       类型          名称
				 key        string        //钥匙     key     =  'fgmhaksjddfdkfg@#$$sdf%asd'
				 imei       string        //设备id   imei    =  '358551050412329'
				 
				1、 get 提交 参数 key 需要再后面  因为中间多了 # 符号 
				2、 17号报文解析问题 默认配置为空时解析问题
	*/
    public function api_get_config_one(){
		
		$event = I('get.');  
		//$event = json_decode(file_get_contents('php://input'), true);

		/* 验证数据密钥 */
		if (!isset($event['key']) && $event['key'] != 'fgmhaksjddfdkfg@#$$sdf%asd') {
			header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');;
			exit("fail");
		} 
		if(!$event['imei']) {
			header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');
			exit("fail");
		}
		
		/* 获取设备信息 */
		$vins_no = $event['imei'];
		$result  = get_info('wear',array('vins_no'=>$vins_no),array('vins_no','imsi','setting'));

		if(!$result){
			header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');
			exit("fail");
		}
		$set_cache = Common::get_device_config_cache();
		
		if(!$result['setting']){
			$setting = Common::get_device_config_cache();
		}else{
			$setting = json_decode($result['setting'],true); 
			$setting['32'] 		= $set_cache['32'];
			$setting['63'] 		= $set_cache['63'];
			$setting['106']		= $set_cache['106'];
			$setting['107'] 	= $set_cache['107'];
			$setting['efence']  = $set_cache['efence'];
		}

		/* 生成设备配置报文 */
		$instructions = array();
		$type  = array('');
		foreach($setting as $key=>$val){
			if(is_numeric($key) && $key != '20'){
				$package = '@B#@,V01,';
				$package .= $key . ',';
				$package .= $this->depater($key,$val);
				$package .= ',@E#@';
				$instructions[] = $package;
			}
		}
		header($_SERVER['SERVER_PROTOCOL'] . ' 200 OK');
		echo implode('',$instructions);
		exit;
	}
			
	public function api_get_config(){
		
		$event = I('get.');  
		//$event = json_decode(file_get_contents('php://input'), true);

		/* 验证数据密钥 */
/* 		if (!isset($event['key']) && $event['key'] != 'fgmhaksjddfdkfg@#$$sdf%asd') {
			header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');;
			exit("fail");
		} */ 
		if(!$event['imei']) {
			header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');
			exit("fail");
		}
		
		/* 获取设备信息 */
		$vins_no = $event['imei'];
		$result  = get_info('wear',array('vins_no'=>$vins_no),array('vins_no','imsi','setting'));

		if(!$result){
			header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');
			exit("fail");
		}

		if(!$result['setting']){
			$setting = Common::get_device_config_cache();
		}else{
			$setting = json_decode($result['setting'],true); 
		}

		/* 生成设备配置报文 */
		$instructions = array();
		$type  = array('');
		foreach($setting as $key=>$val){
			if(is_numeric($key) && $key != '20'){
				$package = '@B#@,V01,';
				$package .= $key . ',';
				$package .= $this->depater($key,$val);
				$package .= ',' . $event['imei'];
				$package .= ',@E#@';
				$instructions[] = $package;
			}
		}
		header($_SERVER['SERVER_PROTOCOL'] . ' 200 OK');
		echo implode('',$instructions);
		exit;
	}
	
	private function depater($type,$value){
		
		switch($type){
			case  '17':
				$list  = array();
				$str   = $value['c'] . ',';
				$str  .= sizeof($value['list']) . ',';
				if(!empty($value['list'])){
					foreach ($value['list'] as $val)
					{   
						$list[]   = array(
							'm'=>$val['m'],
							'n'=>$val['n'],
							'j'=>$val['j'],
						);
						$str .= ($val['m'] . ';' . Common::rep_unicode($val['n']) . ';' . $val['j']) . '|';
					}
					$str  = rtrim($str, '|') . ',';
					$str .= sprintf('%u', crc32($str)); 
				}else{
					$str .='NONE' . ',' .'NONE';
				}
				break;
			case  '18':
				$str .= $value['f'] . ',';
				$str .= $value['y'] . ',';
				$str .= $value['t'] . ',';
				$str .= sprintf('%u', crc32($value['f'].$value['y'].$value['t'])); 
				break;
			case  '19':
				$str  = $value;
				break;
			case  '32':
				$str  = $value . ',';
				$str .= sprintf('%u', crc32($value));
				break;
			case  '45':
				$str  = $value;
				break;
			case  '46':
				$str  = $value;
				break;
			case  '47':
				$str .= $value['s'] . ',';
				$str .= $value['e'] . ',';
				$str .= sprintf('%u', crc32($value['s'].$value['e'])); 
				break;
			case  '49':
				$str  = $value;
				break;
			case  '50':
				$str  = $value;
				break;
			case  '63':
				$str  = $value;
				break;
			case '101':
				$str .= $value['s'] . ',';
				$str .= $value['e'] . ',';
				$str .= sprintf('%u', crc32($value['s'].$value['e'])); 
				break;
			case  '106':
				$str  = $value . ',';
				$str .= sprintf('%u', crc32($value));
				break;
			case  '107':
				$str  = $value;
				break;
			default ;
		}
		return $str;
	}
	
	/** 
	 *	替换中文/数字为unicode
	 */
	private function rep_unicode($value)
	{
		$replace = array(
			'0'=>'0030',
			'1'=>'0031',
			'2'=>'0032',
			'3'=>'0033',
			'4'=>'0034',
			'5'=>'0035',
			'6'=>'0036',
			'7'=>'0037',
			'8'=>'0038',
			'9'=>'0039',
		);
		$temp = array();

		foreach(str_split($value) as $key=>$val){
			if(isset($replace[$val])){
				$temp[] = $replace[$val];
			}else{
				$temp[] = $val;
			}
		}
		$str = implode('',$temp);
		return str_replace('\\u', '', trim(json_encode($str), '"'));
	}
}