var keys = {
	esc: 27,
        enter: 13,
        space: 32,
        up: 38,
        down: 40,
	left:37,
	right:39
};
